LPP Grain — prototype variable font pair

Korean base: Noto Serif KR / Open Cosmos Ink KR Full (SIL Open Font License 1.1).
Latin companion: Rock Salt; see included license files.
Both are derivatives, not typefaces drawn from scratch. They include an animated BOIL axis from 0 to 3. Korean covers all 11,172 modern precomposed Hangul syllables.
